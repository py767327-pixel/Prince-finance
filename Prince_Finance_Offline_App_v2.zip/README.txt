Prince Finance Offline App v2
- Fully offline HTML/CSS/JavaScript app
- IndexedDB for customers and payments
- Payment screenshots saved locally as payment proof
- JSON backup/restore
- No Firebase, login or internet required for normal operation
- Mobile-friendly UI

Open index.html in a modern browser. For a reliable Android APK, wrap this project with Capacitor later.
